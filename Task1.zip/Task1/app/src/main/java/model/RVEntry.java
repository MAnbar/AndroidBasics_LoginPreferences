package model;

public class RVEntry {
    String title;
    String subTitle;
    int photoId;

    public RVEntry(String title, String subTitle, int photoId) {
        this.title = title;
        this.subTitle = subTitle;
        this.photoId = photoId;
    }
}
