package model;

import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.task1.R;

import java.util.List;

public class RVAdapter extends RecyclerView.Adapter<RVAdapter.EntryViewHolder> {

    public List<RVEntry> rvEntries;

    public RVAdapter(List<RVEntry> rvEntries){
        this.rvEntries = rvEntries;
    }
    @Override
    public EntryViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item, viewGroup, false);
        EntryViewHolder evh = new EntryViewHolder(v);
        return evh;
    }

    @Override
    public void onBindViewHolder(EntryViewHolder entryViewHolder, int i) {
        entryViewHolder.title.setText(rvEntries.get(i).title);
        entryViewHolder.subtitle.setText(rvEntries.get(i).subTitle);
        entryViewHolder.entryPhoto.setImageResource(rvEntries.get(i).photoId);
    }

    @Override
    public int getItemCount() {
        return rvEntries.size();
    }

    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
    }

    public static class EntryViewHolder extends RecyclerView.ViewHolder {
        CardView cv;
        TextView title;
        TextView subtitle;
        ImageView entryPhoto;

        EntryViewHolder(View itemView) {
            super(itemView);
            cv = (CardView)itemView.findViewById(R.id.cv);
            title = (TextView)itemView.findViewById(R.id.entry_title);
            subtitle = (TextView)itemView.findViewById(R.id.entry_sub);
            entryPhoto = (ImageView)itemView.findViewById(R.id.entry_photo);
        }
    }
}
