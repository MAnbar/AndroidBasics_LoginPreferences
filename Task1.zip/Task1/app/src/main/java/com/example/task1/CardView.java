package com.example.task1;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.TextView;

public class CardView extends AppCompatActivity {

    TextView entryTitle;
    TextView entrySub;
    ImageView entryPhoto;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_card_view);
        entryTitle = (TextView)findViewById(R.id.entry_title);
        entrySub = (TextView)findViewById(R.id.entry_sub);
        entryPhoto = (ImageView)findViewById(R.id.entry_photo);

        entryTitle.setText("Emma Wilson");
        entrySub.setText("23 years old");
        entryPhoto.setImageResource(R.drawable.d);
    }
}
