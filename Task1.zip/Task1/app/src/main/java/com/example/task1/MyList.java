package com.example.task1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import model.RVAdapter;
import model.RVEntry;

public class MyList extends AppCompatActivity {

    private List<RVEntry> rvEntries;
    private RecyclerView rv;

    public MyList() {
    }

    private void initializeData(){
       rvEntries=new ArrayList<>();
       rvEntries.add(new RVEntry("Thing A","Sub A",R.drawable.a));
       rvEntries.add(new RVEntry("Thing B","Sub B",R.drawable.b));
       rvEntries.add(new RVEntry("Thing C","Sub C",R.drawable.c));
       rvEntries.add(new RVEntry("Thing D","Sub D",R.drawable.d));
       rvEntries.add(new RVEntry("Thing E","Sub E",R.drawable.e));
       rvEntries.add(new RVEntry("Thing F","Sub F",R.drawable.f));
    }
    private void initializeAdapter(){
        RVAdapter adapter = new RVAdapter(rvEntries);
        rv.setAdapter(adapter);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_list);
        rv = (RecyclerView)findViewById(R.id.rv);
        LinearLayoutManager llm = new LinearLayoutManager(this);
        rv.setLayoutManager(llm);

        initializeData();
        initializeAdapter();
    }
}
