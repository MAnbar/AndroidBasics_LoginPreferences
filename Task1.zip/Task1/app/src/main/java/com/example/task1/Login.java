package com.example.task1;

import android.content.Intent;
import android.support.design.widget.TextInputEditText;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Login extends AppCompatActivity {

    private boolean isEmpty(EditText etText) {
        if (etText.getText().toString().trim().length() > 0) {
            return false;
        }
        return true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        final Button button = findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                TextInputLayout layUserName = (TextInputLayout) findViewById(R.id.textInputLayoutUsername);
                TextInputLayout layPassword = (TextInputLayout) findViewById(R.id.textInputLayoutPassword);

                EditText etUserName = (TextInputEditText) findViewById(R.id.textInputUsername);
                EditText etPassword = (TextInputEditText) findViewById(R.id.textInputPassword);

                String strUserName = etUserName.getText().toString();
                String strPassword = etPassword.getText().toString();

                layUserName.setError(null);
                layPassword.setError(null);

                if (TextUtils.isEmpty(strUserName)) {
                    //etUserName.setError("Username can't be empty");
                    layUserName.setError("Username can't be empty");
                    return;
                }
                if (TextUtils.isEmpty(strPassword)){
                    //etPassword.setError("Password can't be empty");
                    layPassword.setError("Password can't be empty");
                    return;
                }

                if (!strUserName.equals("admin")) {
                    layUserName.setError("Wrong Username");
                    return;
                }
                if (!strPassword.equals("admin")){
                    layPassword.setError("Wrong Password");
                    return;
                }
                Intent intent = new Intent(getApplicationContext(), MyList.class);

                startActivity(intent);
            }
        });
    }
}
